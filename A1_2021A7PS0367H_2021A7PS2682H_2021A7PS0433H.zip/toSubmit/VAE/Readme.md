# Generative AI Models

## VAE

```
cd VAE
virtualenv venv
source venv/bin/activate.fish
pip install -r requirements.txt
```

In one terminal:
`python3 train.py`

In the other:
`python3 visualize.py`